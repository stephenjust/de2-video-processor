#include <ci_draw_rect.c>

void vga_draw_rect(draw_rect_params_t *params)
{

}
